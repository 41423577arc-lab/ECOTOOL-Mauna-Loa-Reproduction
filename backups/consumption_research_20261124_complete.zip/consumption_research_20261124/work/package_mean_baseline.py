import csv,json,math,shutil,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[1];O=R/'outputs'/'ABC_原序列自相关检验与均值基线_20261123';S=R/'outputs'/'ABC周消费_ARIMA_修正版_20261122'
def read(p):
 with Path(p).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
checks=read(O/'ABC_原训练序列LjungBox显著性检验.csv');pred=read(O/'ABC_均值基线固定原点预测.csv');scores=read(O/'ABC_均值基线误差指标.csv');old=read(S/'ABC_ARIMA与基准_性能比较表.csv')
overview=[];comparison=[]
for who in 'ABC':
 t=read(S/(who+'_112周建模输入.csv'));mu=sum(float(r['Amount']) for r in t[:108])/108
 rows=[r for r in pred if r['Member']==who];assert len(rows)==4 and all(abs(float(r['Forecast'])-mu)<1e-8 for r in rows)
 p6=next(r['PValue'] for r in checks if r['Member']==who and r['Lag']=='6');p12=next(r['PValue'] for r in checks if r['Member']==who and r['Lag']=='12')
 test=next(r for r in scores if r['Member']==who and r['N']=='4')
 overview.append([who,108,p6,p12,mu,test['MAE'],test['RMSE'],test['sMAPE'],test['MASE']])
 for n in ['30','4']:
  new=next(r for r in scores if r['Member']==who and r['N']==n);prior=next(r for r in old if r['Member']==who and r['N']==n and r['Method']=='HistoricalMean');ar=next(r for r in old if r['Member']==who and r['N']==n and r['Method']=='AutoARIMA')
  assert all(abs(float(new[k])-float(prior[k]))<1e-7 for k in ['MAE','RMSE','sMAPE','MASE'])
  comparison.append([who,n,new['MAE'],ar['MAE'],100*(float(ar['MAE'])-float(new['MAE']))/float(ar['MAE']),new['RMSE'],ar['RMSE']])
 shutil.copy2(S/(who+'_112周建模输入.csv'),O/(who+'_112周建模输入.csv'))
with (O/'ABC_显著性检验与均值预测汇总.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['Member','TrainingN','LB6_PValue','LB12_PValue','WeeklyMeanForecast','TestMAE','TestRMSE','TestsMAPE','TestMASE']);w.writerows(overview)
with (O/'ABC_均值基线与原ARIMA对照.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['Member','EvaluationN','MeanMAE','PriorARIMAMAE','MAEImprovementPct','MeanRMSE','PriorARIMARMSE']);w.writerows(comparison)
explanation='''原训练序列自相关检验与均值预测基线
日期：2026-11-23

一 数据与实验边界
沿用上一轮已核验的正确三位成员自然周数据。每位成员112周；前108周训练至2026-09-27，后4周测试为2026-09-28至10-25。自相关检测只使用前108周，不使用测试值。

二 自相关显著性检验
对未差分、未季节处理的原训练金额计算1至12阶ACF。ACF定义中减去样本均值仅为计算相关系数，不是对序列作差分。
Ljung–Box分别联合检验1至6阶、1至12阶自相关系数为零；原序列检验自由度分别取6、12。
三人这两项联合检验的p值均大于0.05，因此表述为“在所检查的滞后范围内未检出显著联合自相关”。不能表述为“已经证明没有任何自相关”或“已经证明白噪声”。成员A第9阶单个ACF越过近似参照界，亦应保留展示，不能删除；联合12阶检验仍未拒绝。
原序列检验和先前ARIMA拟合残差检验的对象不同，不应把二者的p值混用。原序列的非平稳或分布异常也会影响常规检验解释，本次结果不是单独的平稳性证明。

三 均值模型
采用 y_t = mu + error_t，即有常数的ARIMA(0,0,0)。AR阶数p=0、差分d=0、MA阶数q=0，不包含季节项，不调用自动选阶；以训练序列算术均值直接估计mu。
这不是ARIMA(0,1,0)随机游走；随机游走的点预测通常取最后观测值。本模型固定原点后4周均预测为前108周的算术均值。
此前ARIMA实验已关闭季节项；本轮进一步取消AR、MA和差分结构，建立更简单的历史均值对照。原始金额未删峰值、未变换，未按测试表现调整均值。
另保留30折扩展窗口均值验证：训练长度78至107，每折只使用当时全部训练金额重算均值，再预测下一周。

四 结果与比较
输出MAE、RMSE、sMAPE（200倍口径）和MASE。MASE每折采用该折训练金额相邻变化绝对值的均值缩放；固定4期使用108周训练尺度。
本轮重新计算的均值基线与上一版HistoricalMean指标逐项核对一致。原ARIMA对照表使用上一版同区间结果，没有重新拟合ARIMA或改变评价日期。
固定原点均值模型对三位成员的测试MAE与RMSE均低于此前AutoARIMA；30折中C的RMSE仍是此前ARIMA更低，因此不称均值模型在所有任务和指标上全面占优。
均值基线的采用是按当前数据特征作出的研究简化，不是由不显著p值证明其为最优预测模型。

五 文件与复现
每位成员两张PNG：原序列ACF与显著性检验、固定原点均值预测。CSV包含完整ACF、六项联合检验、12条四期预测、90条滚动均值预测、六行误差指标、与原ARIMA对照及汇总。
将本包解压到可写目录，在MATLAB运行run_mean_baseline即可重算；不依赖ECOTOOL，不进行任何自动选阶。程序会覆盖本目录同名CSV、PNG与MAT文件。
'''
(O/'结果说明与复现.txt').write_text(explanation,encoding='utf-8')
shutil.copy2(R/'work'/'run_mean_baseline.m',O/'run_mean_baseline.m')
manifest={'date':'2026-11-23','model':'ARIMA(0,0,0) with constant / historical mean','p':0,'d':0,'q':0,'seasonal':False,'automatic_identification':False,'fit':'arithmetic mean of available training observations','training_n':108,'test_n':4,'rolling_training_lengths':[78,107],'LB_lags':[6,12],'alpha':.05,'figures':6,'source':'上一轮正确三位成员112周输入；B为经确认净消费，C为个人总支付。','verification':'均值预测及四项指标与上一版HistoricalMean逐项核验一致。'}
(O/'均值模型设置.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
bundle=R/'outputs'/'ABC_自相关检验与均值基线_图表结果包.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
 for file in sorted(O.iterdir()):
  if file.is_file():z.write(file,arcname=file.name)
print(bundle)
for row in overview:print(row)
